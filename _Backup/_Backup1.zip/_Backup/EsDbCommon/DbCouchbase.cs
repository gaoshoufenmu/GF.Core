﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Es
{
    public struct _tCouchbaseInfo
    {
        public string url;
        public string bucket_name;
        public string bucket_pwd;
        public string user;
        public string pwd;
    }

    public interface IDbCouchbase
    {
        //---------------------------------------------------------------------
        bool setup(ref _tCouchbaseInfo couchbase_info);

        //---------------------------------------------------------------------
        string getErrorString();

        //---------------------------------------------------------------------
        bool executeGet(string db_key, out string json_data);

        //---------------------------------------------------------------------
        bool executeStore(string db_key, string json_data);

        //---------------------------------------------------------------------
        bool executeRemove(string db_key);

        //---------------------------------------------------------------------
        List<object[]> getView(string design_name, string view_name, bool descending = false, int limit = 0);

        //---------------------------------------------------------------------
        List<object[]> getView<KeyType>(string design_name, string view_name, KeyType start_key,
            KeyType end_key, bool descending = false, int limit = 0);
    }
}
