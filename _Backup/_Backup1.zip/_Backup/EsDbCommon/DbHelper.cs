﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;

namespace Es
{
    enum DbClass
    {
        DbCouchbase = 0,
        DbMySQL
    }

    public static class DbHelper
    {
        //---------------------------------------------------------------------
        public static IDbCouchbase setupDbCouchbase(string db_dll_file, ref _tCouchbaseInfo couchbase_info)
        {
            Assembly ass = Assembly.LoadFrom(db_dll_file);// 加载dll文件
            Type tp = ass.GetType(DbClass.DbCouchbase.ToString());// 获取类名，命名空间+类名
            IDbCouchbase dc = (IDbCouchbase)ass.CreateInstance(tp.Name);
            //IDbCouchbase dc = (IDbCouchbase)Activator.CreateInstance(tp,true);// 建立实例
            dc.setup(ref couchbase_info);
            return dc;
        }

        //---------------------------------------------------------------------
        public static IDbMySQL setupDbMysql(string db_dll_file, string connection_str)
        {
            Assembly ass = Assembly.LoadFrom(db_dll_file);// 加载dll文件
            Type tp = ass.GetType(DbClass.DbMySQL.ToString());// 获取类名，命名空间+类名
            IDbMySQL db = (IDbMySQL)ass.CreateInstance(tp.Name);
            db.setup(connection_str);
            return db;
        }
    }
}
