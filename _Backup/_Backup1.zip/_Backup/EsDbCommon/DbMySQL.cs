﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Text;

namespace Es
{
    public enum MySQLResult
    {
        Success = 0,
        Failed,
        Timeout
    }

    public delegate void OnMySQLExecuteNonQuery(MySQLResult result, Dictionary<string, string> map_param);

    public delegate void OnMySQLExecuteReader(MySQLResult result, DataTable dt, Dictionary<string, string> map_param);

    public interface IDbMySQL
    {
        //---------------------------------------------------------------------
        void setup(string conection_str);

        //---------------------------------------------------------------------
        void update(float elapsed_tm);

        void asyncExecuteNonQuery(OnMySQLExecuteNonQuery cb, string sql, Dictionary<string, string> map_param);

        void asyncExecuteReader(OnMySQLExecuteReader cb, string sql, Dictionary<string, string> map_param);
    }
}
