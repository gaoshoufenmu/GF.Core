﻿using System;
using System.Collections.Generic;
using Eb;
using Es;

// Parent: EtUCenter， Children：EtChannelService
public class EtChannelProject : EntityDef
{
    //---------------------------------------------------------------------
    public override void declareAllComponent(byte node_type)
    {
        declareComponent<DefChannelProject>();
    }
}
