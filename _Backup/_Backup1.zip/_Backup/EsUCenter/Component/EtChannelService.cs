﻿using System;
using System.Collections.Generic;
using Eb;
using Es;

// Parent: EtChannelProject， Children：Null
public class EtChannelService : EntityDef
{
    //---------------------------------------------------------------------
    public override void declareAllComponent(byte node_type)
    {
        declareComponent<DefChannelService>();
    }
}
