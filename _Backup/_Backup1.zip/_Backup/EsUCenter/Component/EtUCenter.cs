﻿using System;
using System.Collections.Generic;
using Eb;
using Es;

// Parent: EtRoot， Children：EtChannelProject
public class EtUCenter : EntityDef
{
    //---------------------------------------------------------------------
    public override void declareAllComponent(byte node_type)
    {
        declareComponent<DefUCenter>();
    }
}
