﻿using System;
using System.Collections.Generic;
using System.Text;
using Eb;
using Es;

class EsEngineListener : IEsEngineListener
{
    //-------------------------------------------------------------------------
    public void init(EntityMgr entity_mgr, Entity et_node)
    {
        EbLog.Note("EsEngineListener.init()");

        entity_mgr.regComponent<LoginChannelProject<DefChannelProject>>();
        entity_mgr.regComponent<LoginChannelService<DefChannelService>>();
        entity_mgr.regComponent<LoginUCenter<DefUCenter>>();

        entity_mgr.regEntityDef<EtUCenter>();
        entity_mgr.regEntityDef<EtChannelProject>();
        entity_mgr.regEntityDef<EtChannelService>();

        Entity et_ucenter = entity_mgr.createEntity<EtUCenter>(null, et_node);
    }

    //-------------------------------------------------------------------------
    public void release()
    {
        EbLog.Note("EsEngineListener.release()");
    }
}

class Program
{
    //-------------------------------------------------------------------------
    static void Main(string[] args)
    {
        Console.Title = "EsUCenter";

        ProgramConfig config = new ProgramConfig();
        config.load("../../../Media/EsUCenter/EsUCenter.exe.config");
        //config.save();

        EsEngineSettings settings;
        settings.ProjectName = "UCenter";
        settings.NodeType = (byte)_eUCenterNodeType.UCenter;
        settings.NodeTypeString = "UCenter";
        settings.NodeIp = config.NodeIp;
        settings.ListenIp = config.ListenIp;
        settings.NodePort = config.NodePort;
        settings.RootEntityType = "EtNode";
        settings.EnableCoSupersocket = true;
        settings.EnableCoCouchbase = false;
        settings.EnableCoUCenterSDK4Server = false;
        settings.EsEngineExeConfigFilename = "../../../Media/EsUCenter/EsEngine.dll.config";
        settings.Log4NetConfigPath = "../../../Media/EsUCenter/EsUCenter.log4net.config";
        settings.Log4NetConfigZk = "../../../Media/EsUCenter/EsZkClient.log4net.config";

        EsEngine e = new EsEngine(ref settings, new EsEngineListener());
        e.run();
    }
}
