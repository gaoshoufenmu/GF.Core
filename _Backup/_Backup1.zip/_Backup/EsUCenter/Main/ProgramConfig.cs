﻿using System.Collections.Generic;
using System.Configuration;
using Eb;

class ConfigCommon : ConfigurationSection
{
    [ConfigurationProperty("NodeIp", IsRequired = true)]
    public string NodeIp
    {
        get { return (string)this["NodeIp"]; }
        set { this["NodeIp"] = value; }
    }

    [ConfigurationProperty("ListenIp", IsRequired = true)]
    public string ListenIp
    {
        get { return (string)this["ListenIp"]; }
        set { this["ListenIp"] = value; }
    }

    [ConfigurationProperty("NodePort", IsRequired = true)]
    public int NodePort
    {
        get { return (int)this["NodePort"]; }
        set { this["NodePort"] = value; }
    }
}

public class ProgramConfig
{
    //---------------------------------------------------------------------
    public string NodeIp { get; private set; }
    public string ListenIp { get; private set; }
    public int NodePort { get; private set; }

    //---------------------------------------------------------------------
    public ProgramConfig()
    {
        NodeIp = "";
        ListenIp = "";
        NodePort = 0;
    }

    //---------------------------------------------------------------------
    public void load(string config_filename)
    {
        ExeConfigurationFileMap file = new ExeConfigurationFileMap();
        file.ExeConfigFilename = config_filename;
        Configuration config = ConfigurationManager.OpenMappedExeConfiguration(file, ConfigurationUserLevel.None);

        ConfigCommon cfg_common = config.SectionGroups["EsUCenter"].Sections["Common"] as ConfigCommon;
        NodeIp = cfg_common.NodeIp;
        NodePort = cfg_common.NodePort;
        ListenIp = cfg_common.ListenIp;
    }

    //---------------------------------------------------------------------
    public void save()
    {
        ConfigCommon cfg_common = new ConfigCommon();
        cfg_common.NodeIp = NodeIp;
        cfg_common.ListenIp = ListenIp;
        cfg_common.NodePort = NodePort;

        ExeConfigurationFileMap file = new ExeConfigurationFileMap();
        file.ExeConfigFilename = "EsUCenter.exe.config";
        Configuration config = ConfigurationManager.OpenMappedExeConfiguration(file, ConfigurationUserLevel.None);
        if (config.SectionGroups.Get("EsUCenter") == null)
        {
            config.SectionGroups.Add("EsUCenter", new ConfigurationSectionGroup());
        }

        if (config.SectionGroups["EsUCenter"].Sections.Get("Common") == null)
        {
            config.SectionGroups["EsUCenter"].Sections.Add("Common", cfg_common);
        }

        config.Save(ConfigurationSaveMode.Modified);
    }
}
