﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using Eb;
using Es;

public class ProjectConfig
{
    //-------------------------------------------------------------------------
    public string ServiceParentNode { get; private set; }
    public string ServiceNodeTypeString { get; private set; }
    public byte ServiceNodeType { get; private set; }
    public string VerifyMode { get; private set; }
    public string VerifyConfig { get; private set; }
    public string VerifyAccountRegular { get; private set; }
    public string ClientRoute { get; private set; }

    //-------------------------------------------------------------------------
    public ProjectConfig(string xml_data)
    {
        XmlDocument doc = new XmlDocument();
        doc.LoadXml(xml_data);

        // 项目配置信息
        XmlNode node_projectinfo = doc.SelectSingleNode("ProjectConfig/ProjectInfo");
        ServiceParentNode = node_projectinfo.Attributes["ServiceParentNode"].Value;
        ServiceNodeTypeString = node_projectinfo.Attributes["ServiceNodeTypeString"].Value;
        ServiceNodeType = byte.Parse(node_projectinfo.Attributes["ServiceNodeType"].Value);

        // 验证配置信息
        XmlNode node_verifyinfo = doc.SelectSingleNode("ProjectConfig/VerifyInfo");
        VerifyMode = node_verifyinfo.Attributes["Mode"].Value;
        VerifyConfig = node_verifyinfo.Attributes["ConifgString"].Value;
        VerifyAccountRegular = node_verifyinfo.Attributes["AccountRegular"].Value;

        // 客户端路由配置信息
        XmlNode node_clientroute = doc.SelectSingleNode("ProjectConfig/ClientRoute");
        ClientRoute = node_clientroute.Attributes["Key"].Value;
    }
}
