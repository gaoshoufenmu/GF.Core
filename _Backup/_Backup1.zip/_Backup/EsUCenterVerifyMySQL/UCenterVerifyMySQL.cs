﻿using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Data;
using System.Data.Common;
using System.IO;
using System.Linq;
using System.Text;
using Eb;
using Es;

public class UCenterVerifyMySQL : UCenterVerify
{
    //-------------------------------------------------------------------------
    OnUCenterVerifyResponse mResponse;
    IDbMySQL mDbMySQL;

    //-------------------------------------------------------------------------
    public void start(string config_str)
    {
        mDbMySQL = DbHelper.setupDbMysql(".\\EsDbMySQL\\bin\\EsDbMySQL.dll", config_str);
    }

    //-------------------------------------------------------------------------
    public void stop()
    {
    }

    //-------------------------------------------------------------------------
    public void update(float elapsedtime)
    {
        mDbMySQL.update(elapsedtime);
    }

    //-------------------------------------------------------------------------
    public void verify(string token, string account_name, string password, Dictionary<string, string> map_param)
    {
        string verify_sql = string.Format("SELECT AccountId FROM Account WHERE binary AccountName='{0}' AND binary Password = '{1}' ;", account_name, password);
        Dictionary<string, string> pa_dic = new Dictionary<string, string>();
        pa_dic["AccountName"] = account_name;
        pa_dic["Token"] = token;
        mDbMySQL.asyncExecuteReader(_onMySQLExecuteReader, verify_sql, pa_dic);
    }

    //-------------------------------------------------------------------------
    public void logout(string account_name)
    {
        string logout_sql = string.Format("UPDATE Account SET LoginStatus = 'offline' WHERE binary AccountName='{1}'; ", account_name);
        mDbMySQL.asyncExecuteNonQuery(null, logout_sql, null);
    }

    //-------------------------------------------------------------------------
    public void setResponse(OnUCenterVerifyResponse response)
    {
        mResponse = response;
    }

    //-------------------------------------------------------------------------
    void _onMySQLExecuteNonQuery(MySQLResult result, Dictionary<string, object> map_param)
    {
    }

    //-------------------------------------------------------------------------
    void _onMySQLExecuteReader(MySQLResult result, DataTable dt, Dictionary<string, string> map_param)
    {
        ulong account_id = 0;
        string account_name = (string)(map_param["AccountName"]);
        string token = (string)(map_param["Token"]);
        eLoginResult login_result = eLoginResult.unknow;
        if (result == MySQLResult.Success && dt != null)
        {
            DataRow[] rows = dt.Select();
            if (rows.Length == 1)
            {
                account_id = (ulong)((long)rows[0]["AccountId"]);
                login_result = eLoginResult.success;
                //string online_sql = string.Format("UPDATE Account SET LoginStatus = 'online' WHERE AccountId={0}; ", account_id);
                //mDbMySQL.asyncExecuteNonQuery(null, online_sql, null);
            }
            else
            {
                login_result = eLoginResult.accountNotExists;
            }
        }
        else
        {
            login_result = eLoginResult.unknow;
        }

        mResponse(token, account_id, account_name, login_result, map_param);
    }
}
