﻿using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using Eb;
using Es;

public class UCenterVerifySQLServer : UCenterVerify
{
    //-------------------------------------------------------------------------
    OnUCenterVerifyResponse mResponse;

    //-------------------------------------------------------------------------
    public void start(string config_str)
    {
    }

    //-------------------------------------------------------------------------
    public void stop()
    {
    }

    //-------------------------------------------------------------------------
    public void update(float elapsedtime)
    {
    }

    //-------------------------------------------------------------------------
    public void verify(string token, string account_name, string password, Dictionary<string, string> map_param)
    {
    }

    //-------------------------------------------------------------------------
    public void logout(string account_name)
    {
    }

    //-------------------------------------------------------------------------
    public void setResponse(OnUCenterVerifyResponse response)
    {
        mResponse = response;
    }
}
