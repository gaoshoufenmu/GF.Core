﻿//using System;
//using System.Collections.Generic;
//using System.Configuration;
//using System.Linq;
//using System.Text;
//using Eb;

//namespace Es
//{
//    public delegate void DelegateUCenter2ProjectLogin(LoginData login_data);

//    public class DefUCenterSDK4Server : ComponentDef
//    {
//        //---------------------------------------------------------------------
//        public override void defAllProp(Dictionary<string, string> map_param)
//        {
//        }
//    }

//    public class ServerUCenterSDK4Server<TDef> : Component<TDef> where TDef : DefUCenterSDK4Server, new()
//    {
//        //-------------------------------------------------------------------------
//        Dictionary<string, string> mMapUCenter = new Dictionary<string, string>();

//        //-------------------------------------------------------------------------
//        public DelegateUCenter2ProjectLogin OnUCenter2ProjectLogin { get; set; }
//        //public IZkClient ZkClient { get; private set; }
//        public IRpcCallerMQ RpcCallerMQ { get; private set; }

//        //-------------------------------------------------------------------------
//        public override void init()
//        {
//            EbLog.Note("ServerUCenterSDK4Server.init()");

//            defNodeRpcMethod<LoginData>(
//                (ushort)_eUCenterMethodType.login2projectLogin, _ucenter2projectRecvData);

//            var cfg = EsEngine.Instance.Config;
//            RpcCallerMQ = EsEngine.Instance.newRpcCallerMQ(cfg.UCenterMQHostName, cfg.UCenterMQPort,
//                cfg.UCenterMQUserName, cfg.UCenterMQPassword, cfg.UCenterMQVirtualHost);

//            if (RpcCallerMQ != EsEngine.Instance.RpcCallerMQ)
//            {
//                var mq = (EsEngineRabbitMQ)RpcCallerMQ;
//                mq.createNodeMQ();
//            }

//            //ZkClient = EsEngine.Instance.ZkClient;
//            //ZkClient.subscribeChildChanges(cfg.UCenterZkPath, _onZkNode4UCenterChildChanged);
//        }

//        //-------------------------------------------------------------------------
//        public override void release()
//        {
//            if (RpcCallerMQ != EsEngine.Instance.RpcCallerMQ)
//            {
//                EsEngine.Instance.deleteRpcCallerMQ(RpcCallerMQ);
//            }

//            EbLog.Note("ServerUCenterSDK4Server.release()");
//        }

//        //-------------------------------------------------------------------------
//        public override void update(float elapsed_tm)
//        {
//            if (RpcCallerMQ != EsEngine.Instance.RpcCallerMQ)
//            {
//                var mq = (EsEngineRabbitMQ)RpcCallerMQ;
//                mq.update(elapsed_tm);
//            }
//        }

//        //-------------------------------------------------------------------------
//        public override void handleEvent(object sender, EntityEvent e)
//        {
//        }

//        //-------------------------------------------------------------------------
//        public void project2ucenterOnLogin(bool result, LoginData login_data)
//        {
//            EbLog.Note("ServerUCenterSDK4Server.project2ucenterOnLogin() acc=" + login_data.acc);

//            rpcByMQ(login_data.ucenter_mq,
//                (ushort)_eUCenterMethodType.project2loginOnLogin, result, login_data, RpcCallerMQ);
//        }

//        //-------------------------------------------------------------------------
//        // 收到来自UCenter的登陆请求
//        void _ucenter2projectRecvData(LoginData login_data)
//        {
//            EbLog.Note("ServerUCenterSDK4Server._ucenter2projectRecvData() acc=" + login_data.acc);

//            if (OnUCenter2ProjectLogin != null)
//            {
//                OnUCenter2ProjectLogin(login_data);
//            }
//        }

//        //-------------------------------------------------------------------------
//        void _onZkNode4UCenterChildChanged(int result, string data, string[] chdn, Dictionary<string, object> param)
//        {
//            if (result != 0) return;

//            List<string> list_ucenter_node_remote = new List<string>();
//            List<string> l = null;
//            if (chdn != null) l = chdn.ToList();
//            else l = new List<string>();
//            foreach (var i in l)
//            {
//                string[] list_str = i.Split('_');
//                if (list_str.Length != 3) continue;
//                list_ucenter_node_remote.Add(i);
//            }

//            List<string> list_ucenter_node_local = mMapUCenter.Keys.ToList<string>();
//            IEnumerable<string> list_add = list_ucenter_node_remote.Except(list_ucenter_node_local);
//            IEnumerable<string> list_del = list_ucenter_node_local.Except(list_ucenter_node_remote);

//            // 移除
//            foreach (var i in list_del)
//            {
//                EbLog.Note("ServerUCenterSDK4Server Remove: " + i);
//                mMapUCenter.Remove(i);
//            }

//            // 新增
//            foreach (var i in list_add)
//            {
//                EbLog.Note("ServerUCenterSDK4Server Add: " + i);
//                mMapUCenter[i] = i;
//            }
//        }
//    }
//}
