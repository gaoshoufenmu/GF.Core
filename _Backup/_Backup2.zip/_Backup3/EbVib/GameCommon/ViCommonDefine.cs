﻿using System;

//namespace ViCommon
//{
//    //#define GX_ASSERT_ERROR(p)
//    //public class ViMath
//    //{
//    //    public float Max(float a, float b) { return (a < b) ? b : a; }
//    //    public double Max(double a, double b) { return (a < b) ? b : a; }
//    //    public Int16 Max(Int16 a, Int16 b) { return (a < b) ? b : a; }
//    //    public UInt16 Max(UInt16 a, UInt16 b) { return (a < b) ? b : a; }
//    //    public Int32 Max(Int32 a, Int32 b) { return (a < b) ? b : a; }
//    //    public UInt32 Max(UInt32 a, UInt32 b) { return (a < b) ? b : a; }
//    //    public Int64 Max(Int64 a, Int64 b) { return (a < b) ? b : a; }
//    //    public UInt64 Max(UInt64 a, UInt64 b) { return (a < b) ? b : a; }
//    //}

//}
public class ViConst
{
	public static readonly UInt32 MAX_UINT32 = 0XFFFFFFFF;
}