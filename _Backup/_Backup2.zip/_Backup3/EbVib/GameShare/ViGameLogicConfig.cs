public enum ViGameLogicChannel
{
	DB,
	OWN_CLIENT,
	ALL_CLIENT,
	TOTAL,
}
