public enum ViGameLogicEntityType
{
	INF = 1,
	VIGAMEUNIT,
}
