using System;

public enum ViGameUnitClientMethod
{
	INF = 0,
	SUP = INF,
}
public enum ViGameUnitCellMethod
{
	INF = 0,
	SUP = INF,
}
