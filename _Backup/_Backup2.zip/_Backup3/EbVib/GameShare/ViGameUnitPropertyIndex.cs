public enum ViGameUnitPropertyIndex
{
	INF = 0,
	SUP = INF,
}
